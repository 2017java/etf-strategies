---
name: a-share-investment-research
description: analyze a-share market opportunities and trading decisions using a combined framework of market regime, policy, industry, fundamentals, technicals, sentiment, and risk control. use when the user asks about a-share indices, sectors, policy impact, news-driven stock ideas, company research, watchlists, stock codes or names, screenshots of charts, reports, pdfs, csv or excel trading data, or links that may affect investment decisions. route requests into fast stock diagnosis, watchlist comparison, full sector or policy research, or content parsing before analysis. prioritize actionable conclusions, scoring, trade timing, and risk management over generic commentary.
---

# A-Share Investment Research

Use this skill to deliver practical A-share research and execution-oriented analysis. Treat it as a routing skill first: identify the request type, then choose the right workflow depth and output structure.

For detailed rules and reusable output structures, consult:
- [references/templates.md](references/templates.md) for output formats
- [references/a-share-playbook.md](references/a-share-playbook.md) for market-style rules, new-energy prioritization, and trade triggers
- [references/examples.md](references/examples.md) for concrete output examples
- [references/sector-examples.md](references/sector-examples.md) for sector-specific examples and emphasis shifts
- [references/market-rhythm.md](references/market-rhythm.md) for a-share trading-rhythm states such as weak-to-strong turns, continuation, acceleration, and exhaustion
- [references/structured-output.md](references/structured-output.md) for stable section names, compact schemas, and machine-friendly outputs
- [references/scorecards.md](references/scorecards.md) for single-stock, watchlist, and sector-research scoring sheets
- [references/trigger-rules.md](references/trigger-rules.md) for trigger phrases, routing rules, and follow-up handling
- [references/positioning-guide.md](references/positioning-guide.md) for market-regime position sizing and execution guidance
- [references/data-fallbacks.md](references/data-fallbacks.md) for data-source priority, downgrade rules, and evidence-quality labels
- [references/industry-overrides.md](references/industry-overrides.md) for sector-specific weighting and emphasis rules
- [references/execution-playbooks.md](references/execution-playbooks.md) for mechanical position-building, add, reduce, and exit templates
- [references/prompt-bundles.md](references/prompt-bundles.md) for high-frequency user intents and recommended answer depth

## Workflow decision tree

Follow this order:

1. Classify the request.
2. Gather the minimum required context and data.
3. Choose the matching workflow.
4. Produce the output in the matching format.
5. End with a direct action view: observe, pilot position, add, reduce, avoid, or wait.

Classify requests into exactly one of these modes:

- **mode 1: stock quick diagnosis**
  - Trigger when the input is a stock name, stock code, single screenshot, or a short question like “怎么看”“能不能买”“有没有支撑”.
- **mode 2: watchlist comparison**
  - Trigger when the input contains multiple stocks, a watchlist, or a request to rank, compare, or filter candidates.
- **mode 3: sector or policy research**
  - Trigger when the input is an industry, policy, news event, earnings update, macro theme, or a request to mine beneficiaries.
- **mode 4: content parsing first**
  - Trigger when the user provides a link, pdf, report, csv, excel file, or long article without clearly asking for investment analysis yet.

If a request could fit multiple modes, prefer the more decision-oriented one. Use the trigger library in [references/trigger-rules.md](references/trigger-rules.md) when the user’s wording is ambiguous.

## Core operating principles

- Start from the top-down frame: market regime, policy direction, sector structure, then company and trade execution.
- For single-stock and watchlist tasks, default to concise diagnosis rather than a long report.
- For sector, policy, and news tasks, default to full research depth.
- Treat technical analysis as mandatory for stock and watchlist tasks unless the user explicitly asks to ignore it.
- Treat sentiment as an auxiliary layer. Use it to judge urgency, crowding, and chase risk, not to replace fundamentals or trend structure.
- Favor direct conclusions and execution thresholds over broad educational explanations.
- Separate “logic is correct” from “timing is right”.
- If evidence is mixed, say so explicitly and reduce confidence.
- When the user asks about a specific sector such as photovoltaics, energy storage, semiconductors, brokers, banks, ai infrastructure, or consumer electronics, adapt the emphasis and scoring weights within the same master framework rather than changing frameworks entirely. Use [references/industry-overrides.md](references/industry-overrides.md).
- Always label the conclusion confidence as **high**, **medium**, or **low** based on data completeness, source quality, and signal alignment.

## Data gathering rules

Use available tools and inputs in this priority order:

1. Official or primary sources for policy, regulation, company filings, and exchange notices.
2. Market and quote data for price, volume, trend, and relative strength.
3. User-provided files, screenshots, links, csv, excel, and pdf documents.
4. Reputable financial media and industry reporting.

When the user provides a token or connector for a broker or market-data service, use it.
If no broker connector or token is available, fall back to free and public data sources.
If key data is unavailable, continue with a downgraded evidence label instead of stopping. Use the fallback logic in [references/data-fallbacks.md](references/data-fallbacks.md).

When parsing files or links:

1. Extract and summarize the core content.
2. Identify whether the content is policy, news, earnings, research, price data, or chart evidence.
3. If the user already asked for investment implications, continue directly into the matching workflow.
4. If the user only asked what the content says, summarize first and ask whether to continue into investment analysis.

When handling chart screenshots:

1. Identify whether the image primarily shows price structure, indicators, or annotations.
2. Prioritize trend, platform, relative strength, and volume clues over exotic indicators.
3. Treat image-based chart reads as medium or low confidence unless price data is also available.
4. Still provide a clear timing view and explain what additional data would upgrade confidence.

## Analysis stack

Apply these layers in order when relevant:

### 1. market regime

Assess the broad A-share environment:

- index trend and breadth
- risk appetite and style preference
- sector rotation state
- whether the market rewards trend-following, bottom-fishing, or defense

Summarize the environment in one short paragraph before stock-level recommendations.

### 2. policy and macro

Assess whether policy is supportive, neutral, corrective, or restrictive.
For policy-heavy industries, explicitly judge whether the current stage is:

- expansion
- consolidation
- capacity clearing
- earnings recovery
- theme speculation without earnings support

### 3. sector and industry structure

Identify the beneficiary chain, transmission path, and bottlenecks.
For sector research, explicitly answer:

- what changed
- which subsegments benefit first
- which firms can actually monetize the change
- what could invalidate the thesis

### 4. company fundamentals

Judge companies with emphasis on:

- industry position and client quality
- product or technology edge
- profitability quality and cash flow
- balance-sheet resilience
- catalysts over the next one to two quarters

### 5. technical structure

For stock or watchlist tasks, always inspect:

- weekly and daily trend alignment
- position relative to key moving averages and prior platforms
- breakout or pullback structure
- volume-price behavior
- relative strength versus sector and market
- whether the current area is startup, trend continuation, acceleration, exhaustion, or breakdown

Prefer simple, robust signals over indicator overload.

### 6. sentiment and positioning

For A-share trading timing, also classify the setup using the rhythm states in [references/market-rhythm.md](references/market-rhythm.md). Use these states to decide whether the current setup is a weak-to-strong turn, leader divergence, trend continuation, acceleration, exhaustion, or only a rebound attempt.


Judge whether the trade is early, crowded, or fading.
Useful signals include:

- sector popularity and crowding
- gap-up or acceleration behavior
- follow-through quality after news
- whether leaders are strengthening or lagging

### 7. trade execution and risk control

Always convert analysis into an execution stance:

- observe
- pilot position
- add on confirmation
- reduce into strength
- avoid for now
- wait for pullback or confirmation

State what would confirm the trade and what would invalidate it. When the user asks for explicit position management, use the mechanical templates in [references/execution-playbooks.md](references/execution-playbooks.md).

## Scoring framework

Use a 100-point model whenever the user asks for scoring, screening, comparison, or a buy-sell view.
For single-stock or watchlist analysis, default to this model unless the user asks for a purely qualitative answer.

- **industry and policy: 25 points**
  - sector position: 10
  - policy support: 8
  - industry momentum or margin improvement: 7
- **company fundamentals: 35 points**
  - industry position: 8
  - product or technical moat: 8
  - earnings and cash-flow quality: 7
  - anti-cycle resilience: 6
  - near-term catalyst clarity: 6
- **technical and positioning: 25 points**
  - trend structure: 8
  - volume-price health: 6
  - relative strength: 5
  - current position and risk-reward: 6
- **execution and risk control: 15 points**
  - buy-point clarity: 5
  - invalidation or stop logic: 5
  - position sizing suitability: 5

Interpretation:

- **85 to 100**: priority candidate, actionable when trigger conditions are met
- **75 to 84**: good candidate, keep in focus and wait for better timing if needed
- **65 to 74**: observation only, logic exists but timing or evidence is weak
- **below 65**: avoid or deprioritize

Use the detailed scoring guidance in [references/a-share-playbook.md](references/a-share-playbook.md) when the user asks for a more granular or A-share-specific view.

## Workflow 1: stock quick diagnosis

Use this for a single stock, stock code, name, or screenshot.
Keep the answer concise and execution-oriented. Apply the rhythm-state logic from [references/market-rhythm.md](references/market-rhythm.md) before issuing the action view.

### Required output

Use the standard section names from [references/structured-output.md](references/structured-output.md). For programmatic or table-oriented tasks, prefer the compact schema or a stable table layout.

Use this structure:

1. **market backdrop**
   - one short paragraph on broad market and sector context
2. **industry support**
   - one short paragraph on whether the stock’s industry currently has policy or cycle support
3. **fundamental score**
   - score and two to four reasons
4. **technical score**
   - score and two to four reasons
5. **sentiment and timing**
   - say whether it is early, confirmatory, crowded, or weakening
6. **action view**
   - choose one: observe / pilot position / add on confirmation / reduce / avoid / wait
7. **risk points**
   - list the main invalidation factors
8. **position suggestion**
   - light / normal / high-conviction only when evidence supports it
9. **confidence**
   - high / medium / low and one sentence on why

### Stock quick diagnosis rules

- Do not produce a long industry report unless the user asks for it.
- If the user provides a chart screenshot, prioritize technical structure first, then add basic industry and fundamental context.
- If evidence is incomplete, still provide a provisional view and state what data is missing.
- Always distinguish between “company is acceptable” and “entry timing is acceptable”.
- When the chart is extended after a sharp multi-day run, explicitly warn about chase risk even if the medium-term thesis remains valid.

## Workflow 2: watchlist comparison

Use this for multiple stocks, shortlists, and ranking tasks.

### Required output

1. one short paragraph on market and sector backdrop
2. a ranked list or grouped tiers
3. for each stock, provide:
   - brief thesis
   - fundamental score
   - technical score
   - action label
4. end with:
   - top priorities
   - names to wait on
   - names to avoid for now
   - overall position bias for the basket
   - confidence label

### Watchlist rules

- Compare names on the same logic set.
- Do not let a single one-day move dominate the ranking unless the task is explicitly short-term trading.
- If the user’s goal is unclear, default to swing-trading horizon rather than intraday.
- If the list mixes industries, first cluster by sector and then rank within and across clusters.

## Workflow 3: sector or policy research

Use this for sector, policy, news, earnings, and beneficiary-mining tasks.

### Required output

1. **executive conclusion**
2. **macro and policy judgment**
3. **industry trend judgment**
4. **transmission path**
5. **beneficiary screening**
6. **screening logic**
7. **risks**
8. **execution view**
9. **position guidance**
10. **confidence**

### Sector or policy research rules

- Explicitly separate headline impact from earnings impact.
- Rank first-order beneficiaries above second-order mapping names.
- Avoid treating all stocks in a hot theme as equal beneficiaries.
- If the event is mainly narrative and monetization is unclear, say so and downgrade action urgency.

## Workflow 4: content parsing first

Use this when the user gives a link or file without a clear investment request.

### Required output

1. **what the content says**
2. **why it may matter for investment**
3. **which analysis path fits next**
   - stock diagnosis / watchlist comparison / sector research / no further analysis needed

### Content parsing rules

- Summarize first.
- Only continue automatically into deeper analysis if the user already asked for implications, beneficiaries, buy-sell points, or screening.
- If the user asked only for summary, end with a concise next-step question.

## Final response discipline

Before finalizing any answer, ensure all of the following are true:

- The output depth matches the request depth.
- The conclusion is actionable.
- The answer distinguishes thesis, timing, and risk.
- Confidence is labeled.
- Position guidance matches market regime and evidence quality.
- If data is partial, the answer clearly says what is inferred versus verified.

## Answer-length and output-control rules

Adjust answer depth to the user’s intent:

- **conclusion only**: one short backdrop paragraph, scores if relevant, one action label, main risk, and position suggestion
- **normal execution mode**: default depth for most stock, watchlist, and sector tasks
- **full research mode**: use when the user explicitly asks for a full framework, deep dive, or institutional-style breakdown
- **table-first mode**: use when the user asks for rankings, comparisons, or screening results across multiple names

If the user’s prompt matches a high-frequency pattern, consult [references/prompt-bundles.md](references/prompt-bundles.md) and mirror the recommended structure.

## Sector-specific adaptation rules

Before finalizing any sector conclusion:

1. Check whether a sector override exists in [references/industry-overrides.md](references/industry-overrides.md).
2. Adjust the scoring emphasis and catalyst logic accordingly.
3. Keep the same master output structure so results remain comparable across sectors.

## Mechanical execution rules

When the user asks for more explicit trade handling, or when the answer would benefit from a concrete plan, map the stance into a mechanical path:

- **pilot position**: initial exposure only, wait for confirmation before scaling
- **add on confirmation**: scale only after breakout confirmation, successful pullback hold, or relative-strength improvement
- **reduce into strength**: trim into extension, event crowding, or weak follow-through
- **exit or avoid**: do not average down into broken structure unless the user explicitly wants a contrarian recovery framework

Use [references/execution-playbooks.md](references/execution-playbooks.md) to specify stepwise actions when appropriate.
