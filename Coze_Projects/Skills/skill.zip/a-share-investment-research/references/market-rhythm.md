# A-Share trading rhythm rules

Use this file to refine timing in A-share style trading. Apply these rules after the core thesis is established and before issuing a final execution view.

## Rhythm states

Classify the stock or sector into one of these states:

### 1. weak-to-strong turn
Use when a stock or sector was weak or ignored, then starts to show relative strength.
Signals:
- price reclaims a key platform or medium-term average after a repair phase
- leaders stop making lower lows
- volume expands on up days and contracts on pullbacks
- follow-through appears on day two or day three rather than only on the trigger day
Execution bias:
- suitable for pilot positions
- add only if follow-through holds and the trigger level is not lost
Risk note:
- if the move fails immediately and falls back under the reclaimed level, downgrade quickly

### 2. divergence and strengthening
Use when the sector is mixed but the leader holds up better than peers.
Signals:
- leader is above platform while followers remain below
- pullbacks are shallow and relative strength improves
- bad news no longer causes heavy breaks
Execution bias:
- suitable for leader-only exposure
- avoid weaker followers until breadth improves
Risk note:
- if leadership rotates away, reduce quickly because this state depends on narrow sponsorship

### 3. trend continuation
Use when the trend is already established and price is consolidating above prior breakout zones.
Signals:
- weekly and daily trends align
- pullback is orderly and volume contracts
- rebound day restores strength without excessive chase behavior
Execution bias:
- best state for add-on-confirmation
- prefer pullback entries and rebound confirmations over emotional breakouts
Risk note:
- if the stock loses the last valid continuation platform, downgrade from add to observe or reduce

### 4. acceleration stage
Use when price expands rapidly after the market has already recognized the thesis.
Signals:
- multiple wide-range bars in a short period
- obvious volume spike or high gap behavior
- sentiment and discussion heat rise sharply
Execution bias:
- poor state for fresh large entries
- suitable for holders to manage gains and tighten risk
Risk note:
- acceleration often improves paper profits but worsens reward-to-risk for new money

### 5. end-of-move or exhaustion
Use when strong price action no longer converts into quality follow-through.
Signals:
- large volume but weak close
- repeated gap-up failure
- leader lags sector or news no longer pushes price materially higher
Execution bias:
- reduce into strength or avoid new entry
Risk note:
- this is where many users confuse a good company with a good entry

### 6. breakdown and rebound attempt
Use when the prior structure has already failed and the stock is only attempting a technical bounce.
Signals:
- price remains below the key platform or trend line
- bounce occurs with limited relative strength
- rebound is driven by short covering rather than new sponsorship
Execution bias:
- avoid calling this a trend trade
- at most classify as observe unless stronger repair evidence appears
Risk note:
- do not upgrade just because a rebound looks sharp from oversold levels

## A-share timing principles

- Prefer the first orderly confirmation after a repair, not the most emotional first spike.
- Prefer leader strength with shallow pullback over laggard bottom-fishing.
- Prefer volume expansion on confirmation days and contraction on pullback days.
- Downgrade any setup that depends on a single headline but lacks day-two confirmation.
- In high-beta sectors such as photovoltaics, semiconductors, brokers, or AI infrastructure, demand stricter timing discipline because emotional extensions are common.

## Action mapping by rhythm state

- weak-to-strong turn -> pilot position
- divergence and strengthening -> pilot position or focused add in the leader only
- trend continuation -> add on confirmation
- acceleration stage -> hold or reduce into strength, do not aggressively chase
- end-of-move or exhaustion -> reduce or avoid
- breakdown and rebound attempt -> observe or avoid

## Confidence adjustments

- Upgrade confidence when thesis, sector breadth, and timing state align.
- Keep confidence at medium when the thesis is fine but timing is only a rebound attempt.
- Set confidence to low when evidence depends mainly on screenshots, noisy indicators, or second-hand media without price confirmation.
