# Trigger Rules

Use this file to route common A-share user questions into the right workflow quickly and consistently.

## 1. Common trigger phrases

### Route to stock quick diagnosis
Typical phrases:
- 怎么看这只票
- 这票能不能买
- 还有没有支撑
- 帮我看下这个代码
- 这张图怎么看
- 今天能不能上车
- 这个位置能买吗

Default behavior:
- keep the answer concise
- use market backdrop plus industry support plus fundamental and technical scores
- end with one direct action label

### Route to watchlist comparison
Typical phrases:
- 帮我比较一下这几只股票
- 哪个更强
- 帮我筛一下自选股
- 这几只谁优先
- 给我排个优先级
- 哪几个值得重点跟踪

Default behavior:
- rank or tier the list
- use a comparable scoring frame
- avoid long prose for every name

### Route to sector or policy research
Typical phrases:
- 这个政策利好哪些方向
- 帮我挖掘受益标的
- 这个新闻怎么影响a股
- 某个行业接下来怎么看
- 财报变化意味着什么
- 这条产业链谁先受益

Default behavior:
- run the full research workflow
- prioritize transmission path and beneficiary quality
- separate narrative impact from earnings impact

### Route to content parsing first
Typical phrases:
- 你先帮我总结一下这个链接
- 这份pdf讲了什么
- 看看这个报告主要内容
- 帮我解读这篇文章

Default behavior:
- summarize first
- do not automatically expand into trade advice unless the user clearly asks for it

## 2. Mixed requests

When a request contains both summary and investment analysis, skip the pause and do both in order:
1. summarize the content
2. move into the appropriate investment workflow

Examples:
- “帮我总结这个政策，并挖掘受益股” → summarize, then sector research
- “看看这张图，然后告诉我有没有买点” → chart read, then stock quick diagnosis

## 3. Follow-up handling

### If the user asks “展开讲” or “详细点”
- increase depth inside the current mode first
- do not switch modes unless the user’s goal changed

### If the user asks “只看技术面”
- keep market backdrop minimal
- focus on trend, structure, volume-price, relative strength, timing, and invalidation

### If the user asks “只看基本面/行业逻辑”
- reduce technical detail to a brief timing disclaimer
- keep scoring if helpful, but do not force a technical section

### If the user asks “给结论就行”
- compress into one-paragraph backdrop plus scores plus direct action

## 4. Time horizon assumptions

If horizon is not specified, assume:
- single-stock and watchlist tasks: swing trade or medium-short holding period
- policy and sector tasks: one to two quarter research horizon
- screenshot-only chart tasks: short swing horizon unless otherwise stated

If the user explicitly asks about intraday, T+1 style rhythm, or very short-term timing, say that the framework still applies but technical timing gets higher weight.
