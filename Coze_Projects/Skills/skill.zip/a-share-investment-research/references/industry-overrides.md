# Industry Overrides

Use this file to adjust emphasis without changing the master framework. Keep the same output structure but change what matters most.

## 1. Photovoltaics and energy storage

### Core lens
- policy and capacity-clearing stage
- demand continuity versus supply pressure
- system value, inverter or pcs quality, and delivery ability
- price repair versus earnings repair

### Weight shift
- increase policy and industry-stage weight
- increase technical timing weight for bottom-repair and rebound names
- downgrade narrative-only mapping names without earnings linkage

### Preferred expression
- energy storage system, pcs, inverter, and power-electronics leaders first
- photovoltaic equipment and high-barrier auxiliary names second
- main-chain rebound names only when price and inventory signals improve

## 2. Semiconductors

### Core lens
- domestic substitution and policy support
- inventory cycle and utilization recovery
- customer quality and product validation stage
- capex discipline and margin recovery

### Weight shift
- increase product moat and catalyst clarity
- increase policy and industrial-upgrade weight
- treat technical breakouts after long bases as more meaningful than noisy short-term spikes

### Preferred expression
- equipment, materials, and verified design leaders before pure theme names

## 3. Brokers and capital-markets names

### Core lens
- market turnover and risk appetite
- reform expectations and policy signaling
- proprietary risk and balance-sheet quality
- whether the move is a short beta burst or a sustained market-style shift

### Weight shift
- increase market-regime weight
- reduce long narrative sections and emphasize timing and turnover confirmation

## 4. Banks and high-dividend defense

### Core lens
- macro growth expectations
- dividend attractiveness and valuation
- balance-sheet stability and bad-loan concerns
- role as defense versus core upside engine

### Weight shift
- increase fundamentals and resilience
- reduce technical chase bias; prefer pullback and allocation language

## 5. AI infrastructure and computing chain

### Core lens
- policy support and capex visibility
- real order conversion versus theme attention
- supply-chain bottlenecks and delivery ability
- whether valuation already discounts the medium-term story

### Weight shift
- increase catalyst clarity and earnings linkage
- penalize names whose logic is purely conceptual

## 6. Consumer electronics and export manufacturing

### Core lens
- product cycle, demand visibility, and customer concentration
- margin stability and exchange-rate effects
- whether the move is event-driven or sustained earnings recovery

### Weight shift
- increase customer quality and near-term catalyst clarity
- increase timing discipline around launch and shipment cycles
