# Prompt Bundles

Use these bundles to match common user intents with the right answer depth and shape.

## 1. Quick conclusion bundle

Typical prompts:
- 给结论就行
- 简单说
- 能不能买
- 现在怎么看

Output shape:
- one short backdrop paragraph
- key score or two
- direct action label
- main risk
- position suggestion

## 2. Execution bundle

Typical prompts:
- 给我买卖点
- 怎么上车
- 怎么分批
- 什么时候加仓

Output shape:
- backdrop kept short
- technical structure and timing emphasized
- action label plus confirmation and invalidation triggers
- mechanical path from observe to pilot to add or reduce

## 3. Research bundle

Typical prompts:
- 深度分析一下
- 帮我完整研究
- 挖掘受益标的
- 做一版框架

Output shape:
- full sector or policy workflow
- transmission path
- beneficiary buckets
- screening logic
- risks and position guidance

## 4. Table-first bundle

Typical prompts:
- 排个优先级
- 给我表格
- 对比一下
- 帮我筛选

Output shape:
- ranking table first
- then top priorities, waitlist, and avoid list
- minimal long prose

## 5. Parse-then-analyze bundle

Typical prompts:
- 先帮我总结这篇
- 看看这个pdf
- 解读这个链接

Output shape:
1. summarize content
2. identify content type
3. if investment implications were requested, continue into the proper workflow
4. otherwise stop after summary and offer the next analytical step
