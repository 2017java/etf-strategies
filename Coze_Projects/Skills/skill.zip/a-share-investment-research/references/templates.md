# Output Templates

Use these templates when the main skill instructions call for a concise diagnosis or full research note.

## Template: stock quick diagnosis

### [stock name or code]

**market backdrop**
[1 short paragraph]

**industry support**
[1 short paragraph]

**fundamental score**
- score: [x]/35
- reasons:
  - [...]
  - [...]

**technical score**
- score: [x]/25
- reasons:
  - [...]
  - [...]

**sentiment and timing**
[early / confirmatory / crowded / weakening + 1 sentence]

**action view**
[observe / pilot position / add on confirmation / reduce / avoid / wait]

**risk points**
- [...]
- [...]

**position suggestion**
[light / normal / high-conviction only]

## Template: watchlist comparison

### market and sector backdrop
[1 short paragraph]

### ranking or grouping
1. [name] — [action label]
2. [name] — [action label]
3. [name] — [action label]

### per-name summary
- **[name]**
  - thesis: [...]
  - fundamental score: [x]/35
  - technical score: [x]/25
  - action: [...]

## Template: sector or policy research

# [theme title]

## executive conclusion
[1 paragraph]

## macro and policy judgment
[1 to 3 short paragraphs]

## industry trend judgment
[1 to 3 short paragraphs]

## transmission path
1. [...]
2. [...]
3. [...]

## beneficiary screening
- subsegment 1: [...]
- subsegment 2: [...]
- representative names: [...]

## screening logic
- [...]
- [...]

## risks
- [...]
- [...]

## execution view
[core theme / structural opportunity / short-lived theme]

## position guidance
[conservative / balanced / aggressive, with one sentence]
