# Positioning Guide

Use this file to translate analysis quality and market regime into position guidance.

## 1. Market-regime templates

### Trend-following market
Characteristics:
- leaders keep making new highs
- breakouts get follow-through
- market rewards strong sectors and relative strength

Position guidance:
- high-conviction setup with strong timing: normal to high-conviction only
- good logic but imperfect timing: pilot position first
- weak timing or crowded extension: wait for pullback rather than chase size

### Bottom-recovery market
Characteristics:
- old leaders attempt repair
- rebounds are violent but uneven
- many names rise before earnings repair is proven

Position guidance:
- recovery leaders: light to normal
- structural alpha names: normal if signals align
- high-beta rebounds: light only unless price repair is confirmed

### Defensive or risk-off market
Characteristics:
- failed breakouts are common
- strong themes narrow quickly
- capital rotates to defense or high-dividend styles

Position guidance:
- strong thesis plus clean trend: light to normal only
- mixed evidence: observe or wait
- high-beta names: avoid or keep as tiny probes only

## 2. Evidence-quality adjustment

### High confidence
Use when:
- source quality is strong
- core data is available
- thesis, timing, and market regime broadly align

Suggested sizing:
- one step higher within the market-regime template

### Medium confidence
Use when:
- some data is inferred or delayed
- the main thesis is plausible but not fully confirmed

Suggested sizing:
- follow the default regime template

### Low confidence
Use when:
- data is incomplete, screenshot-only, or primarily narrative
- thesis or timing has major gaps

Suggested sizing:
- one step lower than default or stay in observe mode

## 3. Action-label mapping

### Observe
- thesis may be acceptable
- timing or evidence is not good enough
- no meaningful exposure recommended

### Pilot position
- thesis is acceptable
- timing is acceptable but not fully confirmed
- initial exposure is allowed with clear invalidation

### Add on confirmation
- thesis is strong
- technical structure confirms continuation
- market regime is supportive enough for larger exposure

### Reduce into strength
- thesis may still be valid
- crowding, extension, or event-risk has increased
- protect gains rather than argue with momentum

### Avoid
- thesis weak, timing poor, or both
- do not force a trade because the theme is popular
