# Scorecards

Use these scorecards when the user asks for a ranked view, a comparable framework, or an execution-ready output.

## 1. Single-stock scorecard

Fill this in when analyzing one stock.

- **stock**: [name / code]
- **sector**: [sector]
- **market style**: [trend-following / bottom-recovery / defensive]
- **timing label**: [early / confirmatory / crowded / weakening]

### industry and policy: /25
- sector position: __/10
- policy support: __/8
- industry momentum or margin improvement: __/7
- brief reason: [...]

### company fundamentals: /35
- industry position: __/8
- product or technical moat: __/8
- earnings and cash-flow quality: __/7
- anti-cycle resilience: __/6
- near-term catalyst clarity: __/6
- brief reason: [...]

### technical and positioning: /25
- trend structure: __/8
- volume-price health: __/6
- relative strength: __/5
- current position and risk-reward: __/6
- brief reason: [...]

### execution and risk control: /15
- buy-point clarity: __/5
- invalidation or stop logic: __/5
- position sizing suitability: __/5
- brief reason: [...]

### totals
- total score: __/100
- action label: [observe / pilot position / add on confirmation / reduce / avoid / wait]
- position suggestion: [light / normal / high-conviction only]
- confirmation trigger: [...]
- invalidation trigger: [...]

## 2. Watchlist comparison table

Use this when the user gives multiple stocks.

| stock | sector | fundamental /35 | technical /25 | total /100 | timing label | action |
|---|---:|---:|---:|---:|---|---|
| [name] | [sector] | [x] | [x] | [x] | [label] | [action] |
| [name] | [sector] | [x] | [x] | [x] | [label] | [action] |
| [name] | [sector] | [x] | [x] | [x] | [label] | [action] |

After the table, always add:
- **top priorities**: [...]
- **wait for better timing**: [...]
- **avoid for now**: [...]

## 3. Sector-research screening sheet

Use this for policy, news, or industry mining.

- **theme**: [...]
- **policy or catalyst**: [...]
- **market style**: [...]
- **execution view**: [core theme / structural opportunity / short-lived theme]

### macro and policy judgment
- support level: [supportive / neutral / corrective / restrictive]
- stage: [expansion / consolidation / capacity clearing / earnings recovery / theme speculation]
- brief reason: [...]

### transmission path
1. [...]
2. [...]
3. [...]

### beneficiary buckets
- first-order beneficiaries: [...]
- second-order beneficiaries: [...]
- lower-confidence mapping names: [...]

### representative names
| subsegment | name | why it matters | confidence |
|---|---|---|---|
| [subsegment] | [name] | [...] | [high / medium / low] |
| [subsegment] | [name] | [...] | [high / medium / low] |

### execution summary
- best expression: [...]
- what to avoid: [...]
- key invalidation: [...]
- position guidance: [conservative / balanced / aggressive]
