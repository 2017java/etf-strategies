# Example Outputs

Use these examples to keep the skill practical, concise, and execution-oriented. Match the structure and level of directness, but adapt the facts to the actual case.

## Example 1: single-stock quick diagnosis

### 300274 阳光电源

**market backdrop**
A-shares are in a selective risk-on environment. The market is rewarding stronger policy-backed growth themes and punishing weak breakouts. New-energy names can work, but the cleaner trends are being favored over pure bottom-fishing.

**industry support**
The energy-storage and power-electronics chain has stronger current support than the broader photovoltaic main chain. If sector orders, policy support, and utility-scale storage demand remain intact, the industry backdrop is supportive.

**fundamental score**
- score: 29/35
- reasons:
  - strong industry position and broad product coverage
  - better ability to monetize storage and inverter demand than commodity-like links
  - balance-sheet and delivery capability improve confidence versus weaker peers
  - valuation still needs to be matched by order and margin execution

**technical score**
- score: 20/25
- reasons:
  - daily trend is constructive and sits above key medium-term averages
  - prior breakout area has not been materially broken
  - volume behavior is acceptable, but not yet a full acceleration breakout
  - relative strength versus weaker photovoltaic names is improving

**sentiment and timing**
confirmatory — the thesis and price structure are aligning, but a fresh chase after a sharp burst is less attractive than buying on orderly confirmation.

**action view**
pilot position

**risk points**
- sector rotation away from growth
- orders or profitability disappoint relative to expectations
- break below the recent valid platform on expanding volume

**position suggestion**
normal

## Example 2: watchlist comparison

### market and sector backdrop
The market is allowing structured participation in growth, but it is not a full broad-based bull phase. Inside new energy, energy storage and power electronics deserve more attention than highly crowded bottom-repair names.

### ranking or grouping
1. 阳光电源 — pilot position
2. 德业股份 — wait for cleaner entry
3. 隆基绿能 — observe
4. 通威股份 — avoid for now

### per-name summary
- **阳光电源**
  - thesis: stronger sector position and cleaner execution path inside storage and power electronics
  - fundamental score: 29/35
  - technical score: 20/25
  - action: pilot position
- **德业股份**
  - thesis: strong product positioning, but entry quality matters after sharp short-term runs
  - fundamental score: 27/35
  - technical score: 17/25
  - action: wait
- **隆基绿能**
  - thesis: photovoltaic leader suitable for recovery tracking, but needs clearer industry price repair
  - fundamental score: 24/35
  - technical score: 14/25
  - action: observe
- **通威股份**
  - thesis: high elasticity to sector repair, but still more dependent on price stabilization than storage leaders
  - fundamental score: 21/35
  - technical score: 11/25
  - action: avoid for now

### summary conclusion
Prioritize storage and power-electronics leaders first. Keep photovoltaic leaders on the watchlist for later confirmation. Treat high-beta main-chain rebounds as secondary trades, not core holdings.

## Example 3: policy-driven sector research

# New policy support for grid-side energy storage

## executive conclusion
The policy is more supportive for grid-side and independent energy storage than for commodity-heavy photovoltaic manufacturing. The first beneficiaries are likely storage system integrators, pcs and inverter leaders, and companies with better project delivery and monetization visibility.

## macro and policy judgment
The policy tone is supportive rather than merely rhetorical. It improves the probability that storage deployment continues and that monetization mechanisms become clearer.

## industry trend judgment
This does not automatically lift every new-energy stock. The nearer beneficiaries are system and power-electronics companies. Purely theme-driven names without monetization clarity should rank lower.

## transmission path
1. policy support improves confidence in storage construction and dispatch economics
2. demand first benefits system integration, pcs, inverters, and project delivery players
3. only later does the effect broaden to adjacent suppliers if orders and margins actually improve

## beneficiary screening
- subsegment 1: storage system integration
- subsegment 2: pcs and inverter leaders
- representative names: choose companies with order quality, utility-scale exposure, and execution credibility

## screening logic
- favor monetization clarity over shipment stories
- favor industry leaders with stronger balance sheets and delivery ability
- downgrade theme-only names that lack direct earnings linkage

## risks
- policy implementation is slower than the headline implies
- industry competition compresses margins despite demand growth
- the market has already priced in too much optimism before earnings confirmation

## execution view
core theme

## position guidance
balanced — build around leaders and wait for confirmation on technical structure rather than chasing emotional spikes.

## Example 4: compact machine-friendly output

```json
{
  "request_mode": "stock quick diagnosis",
  "object": "300274.SZ",
  "market_regime": "selective risk-on",
  "key_thesis": "storage and power-electronics logic is stronger than commodity photovoltaic repair",
  "scoring": {
    "industry_policy": 21,
    "fundamentals": 29,
    "technicals": 20,
    "execution_risk": 13,
    "total": 83
  },
  "execution_view": "pilot position",
  "invalidation": "lose recent valid platform on expanding volume",
  "confidence": "medium"
}
```
