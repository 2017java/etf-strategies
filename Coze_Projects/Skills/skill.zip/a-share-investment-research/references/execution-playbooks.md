# Execution Playbooks

Use these playbooks when the user wants explicit, mechanical trade handling. These are not guarantees. They are structured templates for turning a stance into a path.

## 1. Position-building template

### Pilot position
Use when:
- thesis acceptable
- timing acceptable but not fully confirmed
- evidence is medium confidence

Template language:
- initial exposure only
- do not commit full size at the first signal
- wait for confirmation before adding

### Add on confirmation
Use when one or more are true:
- breakout holds with follow-through
- pullback into key support holds and volume contracts
- relative strength continues to improve
- sector leader confirms rather than diverges

Template language:
- add only after confirmation
- avoid adding into a vertical emotional spike without structure

## 2. Reduction template

Use when:
- price is extended from recent base
- crowding is high
- news gap gets weak follow-through
- leader starts lagging while followers chase

Template language:
- reduce into strength rather than waiting for obvious weakness
- lock in gains when reward-to-risk deteriorates

## 3. Exit or avoid template

Use when:
- thesis weakens materially
- technical structure breaks and fails to recover
- policy interpretation was wrong or overestimated
- the move depends on hope rather than confirmation

Template language:
- avoid forcing a trade because the theme is popular
- respect invalidation rather than averaging down blindly

## 4. Suggested phrasing for action labels

### Observe
- keep it on the radar but do not rush exposure

### Pilot position
- acceptable for a small starter position; scale only if confirmation appears

### Add on confirmation
- a better add point appears only if the current structure confirms continuation

### Reduce
- good for trimming into strength or event-driven extension

### Avoid
- not attractive enough on either logic or timing

## 5. Environment-aware bias

### Trend-following market
- allow faster adds after clean confirmation
- tolerate less pullback depth before adding

### Bottom-recovery market
- favor gradual building rather than one-step sizing
- demand stronger confirmation for rebound names

### Defensive market
- keep size conservative
- prefer observe or pilot over aggressive adds
