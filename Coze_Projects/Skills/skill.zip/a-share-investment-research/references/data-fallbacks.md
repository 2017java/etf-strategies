# Data Fallbacks

Use this file when ideal data sources are unavailable. Do not stop the analysis if a useful downgraded answer is still possible.

## 1. Source priority

Prefer sources in this order:
1. official policy documents, exchange filings, company announcements
2. structured market data, broker or quote interfaces, verified financial datasets
3. user-provided csv, excel, pdf, screenshots, and links
4. reputable financial or industry media

## 2. Evidence labels

### High-quality evidence
Use when most of the conclusion relies on:
- official documents
- structured quote or financial data
- verified company disclosures

### Medium-quality evidence
Use when the conclusion relies on:
- partial market data
- chart screenshots without full price history
- reputable media plus some structured data

### Low-quality evidence
Use when the conclusion relies on:
- screenshots only
- secondary commentary without primary confirmation
- incomplete or stale data

Always mention the evidence label indirectly through the final confidence tag.

## 3. Downgrade rules

### No broker token or premium interface
- use public market data or free quote sources
- avoid pretending precision on intraday metrics that are unavailable
- keep the timing view directional rather than over-specific

### No full financial dataset
- use available filings, headlines, and prior business model knowledge
- keep the fundamental score provisional and state which inputs are missing

### Screenshot-only chart evidence
- analyze structure, trend, platform, and obvious volume clues
- avoid claiming precise indicator values or hidden metrics
- set confidence to medium or low unless other data confirms the view

### Link or pdf without structured tables
- summarize the narrative first
- extract explicit catalysts, risks, and beneficiaries
- do not overstate earnings impact without further evidence

## 4. What to say when data is incomplete

Use short formulations such as:
- provisional view because price structure is visible but full quote data is missing
- the sector logic is clear, but the earnings linkage still needs confirmation
- timing looks acceptable from the chart, though confidence is reduced without full turnover data
