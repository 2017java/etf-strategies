# Structured output rules

Use these rules when another tool may consume the answer programmatically or when the user explicitly asks for tables, scorecards, or compact decision outputs.

## Default sections by mode

### mode 1: stock quick diagnosis
Return these sections in order:
1. market_backdrop
2. industry_support
3. fundamental_score
4. technical_score
5. sentiment_timing
6. action_view
7. risks
8. position_suggestion
9. confidence

### mode 2: watchlist comparison
Return these sections in order:
1. market_backdrop
2. ranking
3. per_name_summary
4. best_candidates
5. avoid_or_wait
6. overall_action
7. confidence

### mode 3: sector or policy research
Return these sections in order:
1. executive_conclusion
2. macro_policy_judgment
3. industry_trend
4. transmission_path
5. beneficiary_screening
6. screening_logic
7. risks
8. execution_view
9. position_guidance
10. confidence

### mode 4: content parsing first
Return these sections in order:
1. content_type
2. summary
3. why_it_matters_for_investing
4. suggested_next_step

## Compact schema

When the user asks for a concise answer, tables, json-like structure, or direct decision output, compress the response into a compact schema such as:

- object
- mode
- key_thesis
- scores
- action
- invalidation
- confidence

Example for a single stock:
- object: 300274.SZ
- mode: stock quick diagnosis
- key_thesis: storage and power-electronics logic is stronger than commodity photovoltaic repair
- scores: fundamentals 29/35, technicals 20/25, total 83/100
- action: pilot position
- invalidation: lose recent valid platform on expanding volume
- confidence: medium

## Table guidance

Use tables only when they materially improve comparison. Good use cases:
- watchlist ranking
- stock-pool screening
- sector beneficiary mapping
- scorecard summaries

Good column sets:
- stock | sector | fundamental_score | technical_score | action | confidence
- subsegment | policy benefit | monetization path | representative names | main risk

## JSON-like block guidance

If the user explicitly asks for structured output for downstream tools, return a fenced code block with keys that are stable and easy to parse. Use plain strings and numbers. Avoid nesting more than necessary.

Recommended top-level keys:
- request_mode
- market_regime
- objects_analyzed
- scoring
- execution_view
- invalidation
- confidence

## Stability rules

- Keep section names stable across runs.
- Do not invent new section names when a standard section already fits.
- Put the action view near the end but before confidence.
- Always state invalidation or failure conditions when giving a trading stance.
- If data is partial, state which fields are estimates or provisional judgments.
