# Sector-specific example prompts and response patterns

Use these examples to adapt the master framework to common A-share sectors.

## photovoltaics and energy storage
Prompt examples:
- 光伏反内卷之后，主线该看组件还是储能？
- 储能有没有进入中周期景气上行？
Response pattern:
- emphasize policy tone, capacity clearing, margin repair stage, and storage monetization
- rank storage systems, pcs, inverters, and power electronics ahead of commodity-heavy links when evidence supports it
- for photovoltaic main-chain names, separate valuation repair from earnings repair

## semiconductors
Prompt examples:
- 半导体设备和设计哪个更值得看？
- 国产替代政策对哪些环节更直接？
Response pattern:
- distinguish between equipment, materials, foundry, analog, design, and advanced packaging
- emphasize order visibility, capex cycle, substitution speed, and valuation crowding
- require stricter timing on emotional policy spikes

## brokers
Prompt examples:
- 券商是不是该看 beta 进攻？
- 这轮行情里券商更适合做核心还是脉冲？
Response pattern:
- tie views closely to market turnover, risk appetite, listing pipeline, and policy support for capital markets
- treat brokers as high-beta market proxies and demand stronger confirmation from index and breadth
- downgrade single-stock conviction if the overall market does not confirm

## banks and high-dividend defense
Prompt examples:
- 银行还能不能拿？
- 高股息是不是更适合现在的市场？
Response pattern:
- emphasize yield stability, valuation, macro defense, and market style preference for defense
- use technicals mainly to avoid poor timing rather than to force aggressive buy points
- be careful not to overstate upside in risk-on markets

## ai infrastructure and compute chain
Prompt examples:
- ai 算力链该看服务器还是光模块？
- 这波算力行情是主题还是业绩？
Response pattern:
- separate theme intensity from actual order and earnings delivery
- distinguish infrastructure beneficiaries from pure concept names
- apply stricter crowding and acceleration checks because sentiment can run ahead of fundamentals

## consumer electronics and export manufacturing
Prompt examples:
- 消费电子修复该看什么？
- 出口链的逻辑能持续吗？
Response pattern:
- assess demand repair, inventory cycle, export conditions, client concentration, and margin resilience
- watch for macro, currency, and overseas demand risks
- prefer leaders with customer stickiness and cash-flow stability
