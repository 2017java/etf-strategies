# A-Share Playbook

Use this reference when the user wants finer execution detail, A-share-specific scoring interpretation, or sector-priority rules.

## 1. A-share market-style checklist

Before giving any buy-sell view, decide which market style dominates:

### Trend-following market
Typical signs:
- leading sectors keep making higher highs
- breakouts have follow-through
- pullbacks are shallow and volume contracts
- leaders stay above 20-day and 60-day moving averages

Implication:
- prefer strong sectors and leader stocks
- buy breakouts and first valid pullbacks
- be more tolerant of premium valuations if the trend is clean

### Bottom-recovery market
Typical signs:
- many former laggards rebound together
- gains are driven by valuation repair rather than earnings proof
- leadership rotates quickly
- breakouts often need repeated confirmation

Implication:
- reduce position size on first entry
- prefer leader stocks with balance-sheet strength
- do not assume every rebound becomes a trend

### Defensive or shrinking-risk market
Typical signs:
- weak breadth
- high-to-low rotation into banks, utilities, dividends, or cash-like themes
- breakouts fail often
- bad news causes larger reactions than good news

Implication:
- require stricter buy points
- reduce aggression and shorten holding periods
- prioritize capital preservation over idea completeness

## 2. A-share technical scoring detail

Use these anchors when giving the technical score out of 25.

### Trend structure: 8 points
- 7 to 8: weekly and daily trends aligned upward; above 20-day and 60-day lines; prior breakout held
- 5 to 6: daily trend positive but weekly trend still repairing
- 3 to 4: only an oversold rebound; no confirmed structure
- 0 to 2: clear downtrend or breakdown

### Volume-price health: 6 points
- 5 to 6: breakout on expansion; pullback on contraction; second push re-expands
- 3 to 4: acceptable but not strong
- 0 to 2: price rises on weak volume or falls on heavy volume

### Relative strength: 5 points
- 5: stronger than sector and broader market
- 3 to 4: roughly in line
- 0 to 2: weaker than both

### Position and risk-reward: 6 points
- 5 to 6: first proper pullback after breakout or clean base breakout
- 4: early breakout attempt with acceptable risk
- 2 to 3: extended trend; okay for holders, poor for fresh entry
- 0 to 1: acceleration climax or breakdown area

## 3. Trade triggers

Use these as default execution triggers.

### Pilot-position trigger
Enter with a small initial position when most of these hold:
- sector logic is valid
- stock is stronger than peers
- price reclaims or holds a key average or prior platform
- breakout or reversal occurs with confirming volume
- invalidation level is clear

### Add-on-confirmation trigger
Add only when the first position is working and most of these hold:
- the breakout remains valid after one to five sessions
- pullback is shallow or orderly
- volume contracts on the pullback
- renewed upward push comes with stronger turnover
- sector leaders are still trending, not diverging

### Reduce-into-strength trigger
Trim when several of these appear:
- multi-day acceleration with widening distance from moving averages
- very large volume without further upside efficiency
- gap-up news reaction fails to extend
- peer stocks stop following the leader
- the move has become sentiment-led more than thesis-led

### Avoid-or-wait trigger
Do not chase when most of these hold:
- stock has already run sharply for several sessions
- current price is far above the latest valid pivot
- sector sentiment is crowded
- risk-reward is poor relative to obvious invalidation

## 4. Position sizing guide

Treat this as a default framework, then adapt to user risk tolerance.

- **light**: logic is interesting but timing is early or evidence is incomplete
- **normal**: thesis and timing both acceptable, but not a highest-conviction setup
- **high-conviction only**: only when sector, company, trend, and execution alignment are all strong and invalidation is clear

Never recommend an aggressive position when:
- the market style is defensive
- the thesis is mainly news-driven without earnings support
- the chart is already in a late acceleration phase

## 5. Photovoltaics and energy-storage priority rules

Apply these when the user explicitly focuses on photovoltaic or energy-storage names.

### Sector preference order in the current default framework
Use this as a starting bias unless fresh evidence changes it:
- energy storage systems, large-scale storage integration
- pcs, inverters, and power electronics
- photovoltaic equipment and high-barrier auxiliaries
- photovoltaic module leaders with balance-sheet strength
- high-elasticity photovoltaic main-chain names dependent on price repair
- theme-only mapping names

### What to emphasize in energy storage
Prioritize:
- order quality and project delivery capability
- system integration instead of commodity exposure alone
- independent storage, utility-scale storage, and global channel strength
- monetization clarity, not just shipment growth

### What to emphasize in photovoltaics
Prioritize:
- survival ability through the downcycle
- cost position, balance sheet, and client quality
- technology transition beneficiaries
- evidence of price stabilization, inventory digestion, and capacity discipline

### How to classify names inside photovoltaic recovery
- **core recovery leaders**: balance sheet strong, leading share, can survive and gain share
- **structural alpha names**: equipment, auxiliaries, high-barrier materials
- **high-beta rebound names**: strong elasticity but heavily dependent on price and sentiment repair

## 6. Sentiment interpretation guide

When discussing timing, use one of these labels and explain it in one sentence:

- **early**: thesis is emerging, crowding is low, confirmation incomplete
- **confirmatory**: price and thesis are aligning, good area for acting if risk is defined
- **crowded**: the trade is popular and extended; valid for holders, dangerous for fresh chasing
- **weakening**: relative strength fades or follow-through quality deteriorates

## 7. Output discipline

When uncertain, do not hide behind long text. Use one of these formats:
- logic okay, timing poor
- timing okay, thesis weak
- both acceptable, pilot position possible
- strong thesis and strong timing, add on confirmation
- neither acceptable, avoid
