from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.normalize_ingredients import normalize_ingredients
from src.render_result import render_result
from src.score_risk import score_risk


def run_eval(path: str) -> dict:
    cases = json.loads(Path(path).read_text(encoding="utf-8"))
    passed = 0
    failed = 0
    details = []
    for case in cases:
        normalized = normalize_ingredients(case["input"])
        scored = score_risk(
            normalized_tags=normalized["normalized_tags"],
            decision_confidence=case["confidence"],
        )
        rendered = render_result(scored["risk_level"], scored["hits"])
        actual = rendered["summary_card"]["risk_level"]
        ok = actual == case["expected_level"]
        details.append(
            {
                "name": case["name"],
                "expected": case["expected_level"],
                "actual": actual,
                "ok": ok,
            }
        )
        if ok:
            passed += 1
        else:
            failed += 1
    return {"passed": passed, "failed": failed, "details": details}


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: python scripts/run_local_eval.py tests/fixtures/cases.json")
        return 1
    report = run_eval(sys.argv[1])
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["failed"] == 0 else 2


if __name__ == "__main__":
    raise SystemExit(main())

