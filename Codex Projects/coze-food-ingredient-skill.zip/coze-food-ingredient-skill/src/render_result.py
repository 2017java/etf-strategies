from __future__ import annotations


def _summary_text(level: str, hits: list[dict]) -> str:
    if level == "red":
        return "检测到高风险成分信号，请谨慎食用。"
    if level == "yellow":
        return "存在需关注成分，建议控制摄入频率与总量。"
    if hits:
        return "整体风险较低，但仍建议关注配料结构。"
    return "未发现明显风险信号。"


def render_result(risk_level: str, hits: list[dict]) -> dict:
    top_hits = hits[:3]
    detail_items = [{"name": h["name"], "reason": h["reason"]} for h in hits]
    return {
        "summary_card": {
            "risk_level": risk_level,
            "summary": _summary_text(risk_level, hits),
            "top_hits": [{"name": h["name"], "reason": h["reason"]} for h in top_hits],
        },
        "detail_items": detail_items,
        "disclaimer": "本结果仅供营养健康参考，不构成医疗建议。",
    }

