"""Local simulation package for Coze food ingredient interpreter."""

