from __future__ import annotations

from pathlib import Path

import yaml


def _load_rules() -> list[dict]:
    root = Path(__file__).resolve().parents[1]
    path = root / "data" / "rules" / "risk_rules_v1.yaml"
    content = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    return content.get("rules", [])


def score_risk(normalized_tags: list[str], decision_confidence: float) -> dict:
    tags = set(normalized_tags or [])
    rules = _load_rules()
    hits: list[dict] = []
    score = 0
    has_hard_high = False
    has_medium_or_soft = False

    for rule in rules:
        if not rule.get("enabled", True):
            continue
        if rule.get("tag") not in tags:
            continue
        hit = {
            "rule_id": rule["rule_id"],
            "name": rule["name"],
            "reason": rule["short_reason"],
            "severity": rule["severity"],
            "rule_type": rule["rule_type"],
        }
        hits.append(hit)
        score += int(rule.get("risk_weight", 0))
        if rule["rule_type"] == "hard" and rule["severity"] == "high":
            has_hard_high = True
        if rule["severity"] in {"medium", "high"} or rule["rule_type"] == "soft":
            has_medium_or_soft = True

    if has_hard_high and decision_confidence >= 0.8:
        level = "red"
    elif has_medium_or_soft:
        level = "yellow"
    else:
        level = "green"

    return {
        "risk_level": level,
        "score": score,
        "hits": hits,
        "decision_confidence": decision_confidence,
    }

