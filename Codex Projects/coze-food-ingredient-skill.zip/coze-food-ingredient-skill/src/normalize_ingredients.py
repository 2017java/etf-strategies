from __future__ import annotations

import re
from pathlib import Path

import yaml


def _load_synonyms() -> dict[str, str]:
    root = Path(__file__).resolve().parents[1]
    path = root / "data" / "lexicon" / "ingredient_synonyms_v1.yaml"
    content = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    mapping: dict[str, str] = {}
    for tag, values in content.get("tags", {}).items():
        for value in values:
            mapping[value.strip().lower()] = tag
    return mapping


def normalize_ingredients(raw_text: str) -> dict:
    text = (raw_text or "").strip()
    if not text:
        return {"tokens": [], "normalized_tags": [], "normalize_confidence": 0.0}

    parts = re.split(r"[，,、；;。()\[\]{}]+", text)
    tokens = [p.strip().lower() for p in parts if p.strip()]

    synonym_map = _load_synonyms()
    tags: list[str] = []
    for token in tokens:
        for key, tag in synonym_map.items():
            if key in token:
                tags.append(tag)

    unique_tags = sorted(set(tags))
    confidence = 0.9 if tokens else 0.0
    if not unique_tags:
        confidence = 0.7

    return {
        "tokens": tokens,
        "normalized_tags": unique_tags,
        "normalize_confidence": confidence,
    }

