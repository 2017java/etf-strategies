# UAT Checklist (Coze Food Ingredient Skill v1)

- [ ] Image OCR success path validated with clear ingredient photo
- [ ] Text input path validated with pasted ingredient list
- [ ] Invalid input returns helpful retry guidance
- [ ] Red output only appears when hard high-risk hit and confidence >= 0.8
- [ ] Yellow output appears for medium/soft concern cases
- [ ] Green output appears for low/no concern case
- [ ] Summary card contains level, short summary, top hits
- [ ] Detail panel shows ingredient-level short reasons
- [ ] Disclaimer is always present
- [ ] Output wording avoids medical diagnosis/treatment language
- [ ] 10+ internal beta conversations completed without workflow null-field failures

