# Rule Update Runbook

## Goal

Safely update ingredient risk rules without breaking risk-level stability.

## Steps

1. Edit `data/rules/risk_rules_v1.yaml`.
2. Ensure each new rule includes:
   - `rule_id`, `name`, `tag`, `risk_weight`, `severity`, `rule_type`, `short_reason`, `enabled`
3. Run local regression:
   - `pytest tests -v`
   - `python scripts/run_local_eval.py tests/fixtures/cases.json`
4. Compare red/yellow/green distribution with previous baseline.
5. If significant drift appears, rollback by git revert.

## Rollback

1. `git log -- data/rules/risk_rules_v1.yaml`
2. `git revert <commit>`
3. Re-run regression and republish Coze workflow config.

