# Node Contracts (food_ingredient_v1)

## 1) input_validate

Input:
- `user_input_text: string | null`
- `user_input_image: object | null`

Output:
- `ok: boolean`
- `input_mode: "text" | "image" | "both" | "invalid"`
- `error_message: string`

## 2) ocr_extract

Input:
- `user_input_image`

Output:
- `ocr_text: string`
- `ocr_confidence: number`
- `ocr_ok: boolean`

## 3) normalize

Input:
- `raw_text: string`

Output:
- `tokens: string[]`
- `normalized_tags: string[]`
- `normalize_confidence: number`

## 4) score_risk

Input:
- `normalized_tags: string[]`
- `decision_confidence: number`

Output:
- `risk_level: "red" | "yellow" | "green"`
- `score: number`
- `hits: object[]`

## 5) render

Input:
- `risk_level`
- `hits`

Output:
- `summary_card: object`
- `detail_items: object[]`
- `disclaimer: string`

