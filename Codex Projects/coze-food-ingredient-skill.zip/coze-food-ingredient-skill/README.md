# Coze Food Ingredient Skill (CN v1)

This project provides a deployable baseline for a Coze bot that interprets packaged food and drink ingredient labels.

## Scope (v1)

- Input: image OCR or pasted ingredient text
- Output: red/yellow/green risk card + short detail reasons
- Policy: strict red only when high-risk hard rule hit and confidence >= 0.8
- Data: no long-term storage of raw image/text

## Quick Start

1. Install dependencies (Python 3.11+):
   - `pip install -r requirements.txt`
2. Run tests:
   - `pytest tests -v`
3. Run fixture regression:
   - `python scripts/run_local_eval.py tests/fixtures/cases.json`

## Coze Assets

- Bot prompt: `coze/bot/system_prompt.md`
- Workflow skeleton: `coze/workflow/food_ingredient_v1.workflow.json`
- Node contracts: `coze/workflow/node_contracts.md`

## Notes

- This repo includes local simulation modules so rule behavior can be validated before Coze publish.
- For production Coze deployment, import the workflow JSON, bind to the bot, then run UAT checklist under `docs/qa/uat-checklist.md`.

