from src.normalize_ingredients import normalize_ingredients


def test_normalize_sugar_synonyms():
    text = "water, sugar, citric acid, flavor"
    out = normalize_ingredients(text)
    assert "添加糖" in out["normalized_tags"]
    assert out["normalize_confidence"] > 0
