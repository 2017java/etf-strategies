from src.render_result import render_result


def test_render_contains_disclaimer():
    result = render_result("yellow", [{"name": "添加糖", "reason": "高糖摄入风险"}])
    assert "仅供营养健康参考" in result["disclaimer"]
    assert result["summary_card"]["risk_level"] == "yellow"

