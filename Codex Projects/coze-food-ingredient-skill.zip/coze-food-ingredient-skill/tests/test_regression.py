from pathlib import Path

from scripts.run_local_eval import run_eval


def test_fixture_regression_passes():
    root = Path(__file__).resolve().parents[1]
    report = run_eval(str(root / "tests" / "fixtures" / "cases.json"))
    assert report["failed"] == 0

