from src.score_risk import score_risk


def test_red_requires_high_confidence():
    result = score_risk(
        normalized_tags=["添加糖", "咖啡因"],
        decision_confidence=0.75,
    )
    assert result["risk_level"] != "red"


def test_red_when_hard_high_and_confident():
    result = score_risk(
        normalized_tags=["添加糖"],
        decision_confidence=0.85,
    )
    assert result["risk_level"] == "red"

